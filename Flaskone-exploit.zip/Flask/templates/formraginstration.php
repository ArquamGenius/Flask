<?php
$i=1;
$username=$_POST["username"];
$password=$_POST["password"];
   if ($password=="###" and $username=="Arquam"){
       echo "<a href='Background-color fuufocof9yd96f96fy9cyocy9d8ooyooyfooy64684557868जष्श्श्श्शस्य्य8288338282827277272726ywysgshshdhdhdhhdh987tdgdoyoo9y90569695995' > click to file </a>";
      }else{
         echo "<script> alert('wrong error user name & pass') </script>";
          while(i<=10000000){
             header("Location: index.html");
                            
              $i++;
             
          }
         
         
      }
/*//file handling   
$DATABASEFILE=fopen("Database.txt","r");
$soffile=filesize("Database.txt");
$Filec=fread($DATABASEFILE,$soffile);
echo $Filec."</br>";
echo $soffile;

*/
?>