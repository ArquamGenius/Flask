<?php
     echo phpinfo();
?>
