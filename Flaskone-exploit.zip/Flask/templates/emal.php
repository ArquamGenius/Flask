<?php
//mail();
$email="moarquam997320@gmail.com";
mail($email,"Hi","@&@&&@&@&@&&","@Arquam");
?>